
## Pre requisites:

1. Docker run time.
2. Kubernetes cluster 

## Installation:

1. Build the docker image using the Dockerfile.
  cd load_balancer_ip_list
  docker build -t nginx:1.18.0 .
2. Apply the kubernrtes manifest using the command

  kubectl apply -f manifest.yaml

3. You can see the status of the deplooyments with the below command.

    kubectl get pods sai-test

4. You can access the nginx using http://localhost

5. To get the list of ip address of the containers into a file run the command.

    kubectl get Endpoints sai-test -oyaml > container_ip_list.txt


  
