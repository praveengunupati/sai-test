import org.scalatest.flatspec.AnyFlatSpec

class VisitorsSiteTest extends AnyFlatSpec {

  "Visitirs stack" should "Add name to products" in {
    val site = new VisitorsSite
    val rec: String = """{
          "visitorId": "v2",
          "products": [{
               "id": "i1",
               "interest": 0.78
          }, {
               "id": "i3",
               "interest": 0.11
          }]
      }"""
    val result = site.add_name(rec)

    assert(result === "{\"visitorId\":\"v2\",\"products\":[{\"id\":\"i1\",\"interest\":0.78,\"name\":\"Nike Shoes\"},{\"id\":\"i3\",\"interest\":0.11,\"name\":\"Jeans\"}]}")

  }

}
