
import play.api.libs.functional.syntax._
import play.api.libs.json._

case class Products(
                     var id: String,
                     var interest: Double,
                     var name: String = null

                   )


case class Visits (
                           visitorId: String,
                           products: List[Products]
                         )

class VisitorsSite {

  val productIdToNameMap = Map("i1" -> "Nike Shoes", "i2" -> "Umbrella", "i3" -> "Jeans")

  def add_name (input: String): String ={
    implicit val productsReads: Reads[Products] = (
      (JsPath \ "id").read[String] and
        (JsPath \ "interest").read[Double] and
        (JsPath \ "id").read[String]

      )(Products.apply _)

    implicit val rootReads: Reads[Visits] = (
      (JsPath \ "visitorId").read[String] and
        (JsPath \ "products").read[List[Products]]
      )(Visits.apply _)

    implicit val productsWrites: Writes[Products] = Json.writes[Products]

    implicit val visitsWrites: Writes[Visits] = Json.writes[Visits]

    val t = Json.parse(input).as[Visits]


    for(a <- t.products){
      a.name = productIdToNameMap.get(a.id).get

    }

    Json.stringify(Json.toJson(t))

  }



}

object VisitorsSite {

  def main(args: Array[String]): Unit = {


    val rec1: String = """{
              "visitorId": "v1",
              "products": [{
                   "id": "i1",
                   "interest": 0.68
              }, {
                   "id": "i2",
                   "interest": 0.42
              }]
          }"""

    val rec2: String = """{
          "visitorId": "v2",
          "products": [{
               "id": "i1",
               "interest": 0.78
          }, {
               "id": "i3",
               "interest": 0.11
          }]
      }"""

    val visitsData: Seq[String] = Seq(rec1, rec2)

    var output: Seq[String] = Seq()
    val v = new VisitorsSite

    for ( a <- visitsData){

      output = output :+ v.add_name(a)
    }
    print(output)

  }
}
